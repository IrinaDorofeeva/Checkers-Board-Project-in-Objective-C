# Checkers-Board-Project-in-Objective-C
Drag and Drop Checkers on the Chess Board Exercise Project Written in Objective-C

 
8x8 chest board (one white view with black subviews) was created. White and red checkers on black squares were created. Drag and drop functionality for checkers was implemented. Dragged checkers should land onto nearest to the drop location black square.
Checkers can't be dragged outside of the board.



[![Demo CountPages alpha](https://j.gifs.com/3lgY84.gif)](https://www.youtube.com/embed/lI6s3HnBQv8)

