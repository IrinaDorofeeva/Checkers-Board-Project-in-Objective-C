//
//  ViewController.h
//  SkutHW22Touches2
//
//  Created by Mac on 5/23/16.
//  Copyright © 2016 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

