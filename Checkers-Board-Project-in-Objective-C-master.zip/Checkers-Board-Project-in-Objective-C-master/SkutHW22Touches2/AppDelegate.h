//
//  AppDelegate.h
//  SkutHW22Touches2
//
//  Created by Mac on 5/23/16.
//  Copyright © 2016 Mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

